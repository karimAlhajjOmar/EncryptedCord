#!/bin/bash
apt-get update
apt-get install -y python3-pip python3-tk
pip3 install discord.py python-dotenv
pip3 install cryptography
pip3 install requests